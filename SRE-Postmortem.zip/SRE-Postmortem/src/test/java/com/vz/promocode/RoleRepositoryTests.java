package com.vz.promocode;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.vz.promocode.model.Role;
import com.vz.promocode.model.RoleName;
import com.vz.promocode.repository.RoleRepository;

//@SpringBootTest
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class RoleRepositoryTests {
	@Autowired
	private RoleRepository repo;

	@Test
	public void testCreateRoles() {
		List<Role> role = repo.findAll();
		if (role.size() == 0) {
			Role admin = new Role(RoleName.ROLE_ADMIN);
			Role user = new Role(RoleName.ROLE_USER);
			Role spAdmin = new Role(RoleName.ROLE_SPADMIN);
			repo.saveAll(List.of(spAdmin,admin, user));
		}

//
//		long count = repo.count();
//		assertEquals(3, count);
	}
}

package com.vz.promocode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PromoCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.vz.promocode.config;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.UnsupportedJwtException;

@Component
public class JwtProvider { //responsible for jwt generation,validation,extraction of info from tokens

	private static final Logger logger = LoggerFactory.getLogger(JwtProvider.class);

	//@value--used to inject values from app.properties 
	@Value("${postmortem.app.jwtSecret}")
	private String jwtSecret;

	@Value("${postmortem.app.jwtExpiration}")
	private int jwtExpiration;
	
	//@SuppressWarnings---suppress or ignore warnings coming from the compiler
	//method for generating a jwt token based on the users authentication info
	
	
	/*
	 * generateJwtToken(Authentication authentication): This method takes an
	 * Authentication object as input and returns a JWT token generated based on the
	 * user’s authentication information. The jwtSecret parameter is the secret key
	 * used to sign the token, and jwtExpiration is the token’s expiration time in
	 * seconds.
	 */
	@SuppressWarnings("deprecation")
	public String generateJwtToken(Authentication authentication) {

		//uses the userprinciple obtained from authentication to build the jwt token.
		//The jwtSecret parameter is the secret key used to sign the token
		UserPrinciple userPrincipal = (UserPrinciple) authentication.getPrincipal();
		return Jwts.builder().setSubject((userPrincipal.getUsername())).setIssuedAt(new Date())
				.setExpiration(new Date((new Date()).getTime() + jwtExpiration * 10000))
				.signWith(SignatureAlgorithm.HS256, jwtSecret).compact();
	}

	@SuppressWarnings("deprecation")
	public boolean validateJwtToken(String authToken) {
		try {
			//parse and validate the token, success-->returns true
			//method is used to parse and validate the token. If the token is valid, the method returns true
			Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(authToken);
			return true;
		}
//		catch (SignatureException e) {
//			logger.error("Invalid JWT signature -> Message: ", e.getLocalizedMessage());
//		}
		catch (MalformedJwtException e) {
			logger.error("Invalid JWT token -> Message: ", e.getLocalizedMessage());
		} catch (ExpiredJwtException e) {
			logger.error("Expired JWT token -> Message: ", e.getLocalizedMessage());
		} catch (UnsupportedJwtException e) {
			logger.error("Unsupported JWT token -> Message: ", e.getLocalizedMessage());
		} catch (IllegalArgumentException e) {
			logger.error("JWT claims string is empty -> Message: ", e.getLocalizedMessage());
		}

		return false;
	}
	
	//This method takes a JWT token as input and returns the username extracted from the token. The 
	//parameter is the secret key used to sign the token.

	@SuppressWarnings("deprecation")
	public String getUserNameFromJwtToken(String token) {
		return Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody().getSubject();
	}
}
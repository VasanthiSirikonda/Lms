package com.vz.promocode.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vz.promocode.model.Incedents;

@Repository
public interface IncedentRepository extends JpaRepository<Incedents, Long> {

}

package com.vz.promocode.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.vz.promocode.model.Incedents;
import com.vz.promocode.model.SearchHistory;
import com.vz.promocode.serviceAndImpl.PostmortemService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class PostmortemController {

	@Autowired
	private PostmortemService postmortemService;

	@PostMapping("/readPostmortemExcelFile")
	public ResponseEntity<?> readPostmortemExcelFile(@RequestParam("files") List<MultipartFile> files) {

		return postmortemService.readPostmortemExcelFile(files);
	}

	@PostMapping("/savePostmortems")
	public ResponseEntity<?> savePostmortems(@RequestBody List<Incedents> ins) {

		return postmortemService.savePostmortems(ins);
	}

	@GetMapping("/getPostmortems")
	public ResponseEntity<?> getPostmortems(@RequestParam("key") String key) {

		return postmortemService.getPostmortems(key);
	}

	@PostMapping("/saveSearchHistory")
	public ResponseEntity<?> saveSearchHistory(@RequestBody SearchHistory sh, HttpServletRequest re) {
		sh.setCreatedBy(re.getRemoteUser());
		sh.setCreatedOn(new Date());
		return postmortemService.saveSearchHistory(sh);
	}

	@GetMapping("/getSearchHistory")
	public ResponseEntity<?> getSearchHistory(HttpServletRequest re) {

		return postmortemService.getSearchHistory(re.getRemoteUser());
	}

}

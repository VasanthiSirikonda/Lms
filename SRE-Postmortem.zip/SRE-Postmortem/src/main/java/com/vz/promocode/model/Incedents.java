package com.vz.promocode.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.poiji.annotation.ExcelCellName;
import com.poiji.annotation.ExcelRow;

import lombok.Data;

@Entity

@Data

@Table(name="incedents")
public class Incedents implements Serializable {

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getRow() {
		return row;
	}

	public void setRow(long row) {
		this.row = row;
	}

	public String getTicketNo() {
		return ticketNo;
	}

	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}

	public String getProblemNumber() {
		return problemNumber;
	}

	public void setProblemNumber(String problemNumber) {
		this.problemNumber = problemNumber;
	}

	public String getSeverity() {
		return Severity;
	}

	public void setSeverity(String severity) {
		Severity = severity;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getItDuration() {
		return itDuration;
	}

	public void setItDuration(String itDuration) {
		this.itDuration = itDuration;
	}

	public String getProblem() {
		return problem;
	}

	public void setProblem(String problem) {
		this.problem = problem;
	}

	public String getCorrectiveAction() {
		return correctiveAction;
	}

	public void setCorrectiveAction(String correctiveAction) {
		this.correctiveAction = correctiveAction;
	}

	public String getRca() {
		return rca;
	}

	public void setRca(String rca) {
		this.rca = rca;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getCause() {
		return cause;
	}

	public void setCause(String cause) {
		this.cause = cause;
	}

	public String getSubCause() {
		return subCause;
	}

	public void setSubCause(String subCause) {
		this.subCause = subCause;
	}

	public String getCausedByCGH() {
		return causedByCGH;
	}

	public void setCausedByCGH(String causedByCGH) {
		this.causedByCGH = causedByCGH;
	}

	public String getExecutive() {
		return executive;
	}

	public void setExecutive(String executive) {
		this.executive = executive;
	}

	public String getL5() {
		return l5;
	}

	public void setL5(String l5) {
		this.l5 = l5;
	}

	public String getL6() {
		return l6;
	}

	public void setL6(String l6) {
		this.l6 = l6;
	}

	public String getAsl() {
		return asl;
	}

	public void setAsl(String asl) {
		this.asl = asl;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getApplID() {
		return applID;
	}

	public void setApplID(String applID) {
		this.applID = applID;
	}

	public String getCulprit() {
		return culprit;
	}

	public void setCulprit(String culprit) {
		this.culprit = culprit;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private static final long serialVersionUID = 1L;

	@Id

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@JsonIgnore

	@ExcelRow
	private long row;

	@ExcelCellName("Ticket Number")
	private String ticketNo;

	@ExcelCellName("PIR")
	private String problemNumber;

	@ExcelCellName("Severity")
	private String Severity;

	@ExcelCellName("Date")
	private Date date;

	@ExcelCellName("IT Duration")
	private String itDuration;

	@ExcelCellName("Problem")
	private String problem;

	@ExcelCellName("Corrective Action")
	private String correctiveAction;

	@ExcelCellName("RCA")
	private String rca;

	@ExcelCellName("Summary")
	private String summary;

	@ExcelCellName("Impact")
	private String impact;

	@ExcelCellName("AppName")
	private String appName;

	@ExcelCellName("Cause")
	private String cause;

	@ExcelCellName("Sub Cause")
	private String subCause;

	@ExcelCellName("CausedByCGH")
	private String causedByCGH;

	@ExcelCellName("Executive")
	private String executive;

	@ExcelCellName("L5")
	private String l5;

	@ExcelCellName("L6")
	private String l6;

	@ExcelCellName("ASL")
	private String asl;

	@ExcelCellName("ENTITY")
	private String entity;

	@ExcelCellName("ApplID")
	private String applID;

	@ExcelCellName("Culprit")
	private String culprit;

	@ExcelCellName("State")
	private String state;

}

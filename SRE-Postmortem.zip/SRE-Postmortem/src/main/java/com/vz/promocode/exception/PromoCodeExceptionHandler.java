package com.vz.promocode.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class PromoCodeExceptionHandler extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(PromoCodeNotFoundException.class)
    public ResponseEntity<Object> handlePromoCodeNotFoundException(
    		PromoCodeNotFoundException ex) {
       
        List<String> details = new ArrayList<String>();
        details.add(ex.getMessage());
        
        APIError error = new APIError();
            error.setStatus(HttpStatus.NOT_FOUND);
            error.setMessage(ex.getMessage());
        
            return new ResponseEntity<>(error, HttpStatus.OK);
    }

}

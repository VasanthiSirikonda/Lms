package com.vz.promocode.model;

import lombok.Data;

@Data
public class Login {

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	private String username;
	private String Password;

}

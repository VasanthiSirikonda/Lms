package com.vz.promocode.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.vz.promocode.service.user.UserDetailsServiceImpl;



@SuppressWarnings("deprecation")
@EnableWebSecurity
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private UserDetailsServiceImpl userDetailsService;

	@Autowired
	private JwtEntryPoint unauthorizedHandler;
	
	/*
	 * The authenticationJwtTokenFilter() method does not take any arguments and
	 * simply returns a new instance of the JwtTokenFilter class. This method can be
	 * used to obtain an instance of the JwtTokenFilter class to be used in other
	 * parts of the application.
	 */
	
	@Bean
	public JwtTokenFilter authenticationJwtTokenFilter() {
		return new JwtTokenFilter();
	}
	
	/*
	 * The configure method is a part of the WebSecurityConfigurerAdapter class in
	 * Spring Security. It is used to configure the AuthenticationManagerBuilder
	 * which is responsible for building an AuthenticationManager. The
	 * AuthenticationManager is used to authenticate the user and is an essential
	 * part of the Spring Security framework.
	 */
	
	/*
	 * the configure method takes an instance of AuthenticationManagerBuilder as an
	 * argument. The userDetailsService and passwordEncoder methods are called on
	 * the authenticationManagerBuilder object to configure the
	 * AuthenticationManager. The userDetailsService method is used to set the
	 * UserDetailsService which is responsible for loading user-specific data. The
	 * passwordEncoder method is used to set the PasswordEncoder which is
	 * responsible for encoding the password.
	 */
	@Override
	public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
		authenticationManagerBuilder.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
	}
	
	/*
	 * The passwordEncoder method is a part of the Spring Security framework. It
	 * returns an instance of the BCryptPasswordEncoder class which is used to
	 * encode passwords. The BCryptPasswordEncoder is a one-way hash function that
	 * generates a random salt for each password and then hashes the password with
	 * the salt. This makes it difficult for attackers to reverse-engineer the
	 * password from the hash.
	 */

	/*
	 * The passwordEncoder method is annotated with @Bean which indicates that the
	 * method returns a bean that should be managed by the Spring container. The
	 * PasswordEncoder bean is used by Spring Security to encode and decode
	 * passwords.
	 */
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	/*
	 * the configure method takes an instance of HttpSecurity as an argument. The
	 * http.cors().and().csrf().disable() method is called to disable CORS and CSRF
	 * protection. The authorizeRequests() method is used to configure the
	 * authorization rules. The antMatchers() method is used to specify the URL
	 * patterns that should be allowed or denied access. The
	 * anyRequest().authenticated() method is used to specify that any request that
	 * is not matched by the previous rules should be authenticated. The
	 * exceptionHandling() method is used to configure the exception handling. The
	 * authenticationEntryPoint() method is used to specify the authentication entry
	 * point. The sessionManagement() method is used to configure the session
	 * management. The sessionCreationPolicy() method is used to specify the session
	 * creation policy.
	 * The addFilterBefore() method is used to add a filter before the
	 *  UsernamePasswordAuthenticationFilter. In this case, the
	 *   authenticationJwtTokenFilter() method is called to add 
	 *   the AuthenticationJwtTokenFilter before the 
	 *   UsernamePasswordAuthenticationFilter.
	 */
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.cors().and().csrf().disable().authorizeRequests().antMatchers("/auth/**").permitAll().antMatchers("**/swagger-ui/index.html#/**").permitAll()
				.antMatchers("/api/**").permitAll()
				.anyRequest().authenticated().and().exceptionHandling().authenticationEntryPoint(unauthorizedHandler)
				.and().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

		http.addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
	}
	
	/*
	 * the authenticationManagerBean method is annotated with @Bean which indicates
	 * that the method returns a bean that should be managed by the Spring
	 * container. The super.authenticationManagerBean() method is called to obtain
	 * the AuthenticationManager instance.
	 * 
	 * The authenticationManagerBean method is called by the Spring Security
	 * framework during the application startup process. It is used to expose the
	 * AuthenticationManager as a bean so that it can be used by other parts of the
	 * application.
	 */
	@Override
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

}

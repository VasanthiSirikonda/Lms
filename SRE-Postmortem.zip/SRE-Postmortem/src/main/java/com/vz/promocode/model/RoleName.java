package com.vz.promocode.model;

import lombok.AllArgsConstructor;
import lombok.ToString;

@ToString
@AllArgsConstructor

public enum RoleName {
	ROLE_USER, ROLE_ADMIN, ROLE_SPADMIN

}

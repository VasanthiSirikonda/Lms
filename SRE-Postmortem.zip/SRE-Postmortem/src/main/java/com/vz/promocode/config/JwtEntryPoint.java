package com.vz.promocode.config;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

//allows Spring to detect our custom beans automatically
@Component
public class JwtEntryPoint implements AuthenticationEntryPoint { //AuthenticationEntryPoint is provided by spring security
// this interface is used to commence an authentication schema
	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException e)
			throws IOException, ServletException { //this method is called whenever an unauth user attempts to access secured resource
		// 401
		response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "JwtAuthEntryPoint -> Unauthorized");
	}

}
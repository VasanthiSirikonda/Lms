package com.vz.promocode.serviceAndImpl;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.vz.promocode.model.Incedents;
import com.vz.promocode.model.SearchHistory;

public interface PostmortemService {

	ResponseEntity<?> readPostmortemExcelFile(List<MultipartFile> files);

	ResponseEntity<?> savePostmortems(List<Incedents> ins);

	ResponseEntity<?> getPostmortems(String key);

	ResponseEntity<?> saveSearchHistory(SearchHistory sh);

	ResponseEntity<?> getSearchHistory(String username);

}

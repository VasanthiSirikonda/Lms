package com.vz.promocode.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vz.promocode.config.JwtProvider;
import com.vz.promocode.model.Login;
import com.vz.promocode.model.Role;
import com.vz.promocode.model.RoleName;
import com.vz.promocode.model.SignUp;
import com.vz.promocode.model.User;
import com.vz.promocode.repository.RoleRepository;
import com.vz.promocode.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/auth")
@Slf4j
public class AuthirizationController {
	@Autowired
	private JwtProvider jwtProvider;

	@Autowired
	private UserRepository userrepo;

	@Autowired
	private PasswordEncoder encoder;

	@Autowired
	AuthenticationManager authenticationManager;

//	@Autowired
//	EmailService emailService;

//	@Autowired
//	private NotificationsService notificationService;

//	@Value("$spring.email.username")
//	private String fromEmail;
//
//	@Value("$infra.email.adminEmail")
//	private String adminEmail;

	@Autowired
	private RoleRepository roleRepository;

	@PostMapping("/login")
	public ResponseEntity<Map<String, Object>> login(@RequestBody Login login) {
		Map<String, Object> map = new HashMap<>();

		User user = userrepo.getUser(login.getUsername());
		try {
			if (user != null && user.getStatus().equals("pending")) { //checks if the user has pending state. if so returns forbidden 
				map.put("message", "status-pending");
				return new ResponseEntity<Map<String, Object>>(map, HttpStatus.FORBIDDEN);
			}
			//authenticate the uname name pwd using authenticationManager
			Authentication authentication = authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(login.getUsername(), login.getPassword()));
			//authentication= success, sets the authentication in the security context then generates JWT token,retrives user details and return a response entity with token and user details 
			SecurityContextHolder.getContext().setAuthentication(authentication);

			String jwt = jwtProvider.generateJwtToken(authentication);
			UserDetails userDetails = (UserDetails) authentication.getPrincipal();
			map.put("token", jwt);
			map.put("userDetails", userDetails);
			return new ResponseEntity<Map<String, Object>>(map, HttpStatus.OK);

		} catch (Exception e) {
			map.put("message", e.getMessage());
			e.printStackTrace();
			return new ResponseEntity<Map<String, Object>>(map, HttpStatus.FORBIDDEN);

		}

	}
	

	@PostMapping("/register")
	public ResponseEntity<Map<String, Object>> register(@RequestBody SignUp signup) { //takes the signup obj from the req body and returns resEntity containing map of objs
		Map<String, Object> resp = new HashMap<>(); //creates a map for response

		try {
			if (userrepo.existsByUsername(signup.getUsername())) {
				resp.put("message", "Username is already existed");
				return new ResponseEntity<Map<String, Object>>(resp, HttpStatus.FORBIDDEN);
			}
			if (userrepo.existsByMobile(signup.getMobile())) {
				resp.put("message", "mobile is already existed");
				return new ResponseEntity<Map<String, Object>>(resp, HttpStatus.FORBIDDEN);
			}
			if (userrepo.existsByEmail(signup.getEmail())) {
				resp.put("message", "email is already existed");
				return new ResponseEntity<Map<String, Object>>(resp, HttpStatus.FORBIDDEN);
			}

			//create a set to store user roles
			Set<Role> set = new HashSet<>();

			//determines the user's role based on the provided role in the registration and adds corresponding roles to the set. 
			if (signup.getRole().equals("spadmin")) {
				Role adminRole = roleRepository.findByName(RoleName.ROLE_SPADMIN)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				set.add(adminRole);
			} else if (signup.getRole().equals("admin")) {
				Role userRole = roleRepository.findByName(RoleName.ROLE_ADMIN)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				set.add(userRole);
			} else if (signup.getRole().equals("user")) {
				Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				set.add(userRole);
			}

			//create an obj and set its attibutes.
			User u = new User();
			u.setUsername(signup.getUsername());
			u.setEmail(signup.getEmail());
			u.setFname(signup.getFname());
			u.setLname(signup.getLname());
			u.setStatus("pending");
			u.setRoles(set);
			u.setRole(signup.getRole());
			u.setCreatedDate(new Date());
			u.setMobile(signup.getMobile());
			u.setPassword(encoder.encode(signup.getPassword()));
			u.setBusinessPurpose(signup.getBusinessPurpose());

			//saving the user to repository
			userrepo.save(u);

//			Notifications n = new Notifications();
//			n.setType("new-registration");
//			n.setKey(signup.getUsername());
//			n.setDescription("New user registered to Infra Dashboard. username : " + signup.getUsername());
//			notificationService.saveNotification(n);

			// for admin
//			Email emailforadmin = new Email();
//			emailforadmin.setFrom(fromEmail);
//			emailforadmin.setTo(adminEmail);
////			emailforadmin.setTo("trinadhr1996@gmail.com");
//			emailforadmin.setSubject("Infra User Registration Update");
//			emailforadmin.setBody("<div style='color:#0d0d0d'><br>Hi, <br><br>"
//					+ u.getFname().substring(0, 1).toUpperCase() + "" + u.getFname().substring(1).toLowerCase() + " "
//					+ u.getLname().substring(0, 1).toUpperCase() + "" + u.getLname().substring(1).toLowerCase()
//					+ " has been registered to Infra Dashboard. Please Approve Or Reject. <br><br/> <button style='margin-right:10px;border:none;background-color:green;color:white;border-radius:4px, padding:5px'><a style='text-decoration:none' href='http://localhost:8083/api/approve/'"
//					+ u.getUsername()
//					+ ">Approve</a></button> <button style='margin-right:10px;border:none;background-color:red;color:white;border-radius:4px,padding:5px'><a style='text-decoration:none' href='http://localhost:8083/api/reject/\"+u.getUsername()+\"'>Reject</a></button> <br> <br> Regards, <br> Infra Dashboard. </div>");
//			emailService.sendEmail(emailforadmin);

			// for user
//			Email emailforuser = new Email();
//			emailforuser.setFrom(fromEmail);
//			emailforuser.setTo(signup.getEmail());
//			emailforuser.setSubject("Infra User Registration Update");
//			emailforuser.setBody("Hi " + u.getFname().substring(0, 1).toUpperCase() + ""
//					+ u.getFname().substring(1).toLowerCase() + " " + u.getLname().substring(0, 1).toUpperCase() + ""
//					+ u.getLname().substring(1).toLowerCase() + ",<br>"
//					+ "<br> You have been registered to Infra Dashboard. Please wait for admin's approval.<br> You will be notified shortly.<br> <br> Regards, <br> Infra Dashboard.");
//
//			emailService.sendEmail(emailforuser);
			resp.put("message", "Success");
			return new ResponseEntity<Map<String, Object>>(resp, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			resp.put("message", e.getMessage());
			return new ResponseEntity<Map<String, Object>>(resp, HttpStatus.FORBIDDEN);
		}
	}

	@GetMapping("/test")
	public String test() {
		return "Welcome to the world";
	}

}

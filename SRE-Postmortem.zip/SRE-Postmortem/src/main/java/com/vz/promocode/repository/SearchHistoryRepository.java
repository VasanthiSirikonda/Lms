package com.vz.promocode.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.promocode.model.SearchHistory;

@Repository
public interface SearchHistoryRepository extends JpaRepository<SearchHistory, Long> {

	@Transactional(readOnly=true)
	SearchHistory findBySearchKey(String key);

	@Transactional(readOnly=true)
	List<SearchHistory> findAllByCreatedBy(String username);

}

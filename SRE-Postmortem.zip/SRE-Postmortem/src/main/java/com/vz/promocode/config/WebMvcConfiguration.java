package com.vz.promocode.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

/*WebMvcConfigurationSupport is a class in the Spring 
Framework that provides the configuration behind the
MVC. It is typically imported by adding
@EnableWebMvc to an application @Configuration.

The addCorsMappings method is used to configure 
cross-origin resource sharing (CORS) for the application.

The CorsRegistry object passed to this method is used to
register mappings between allowed origins, methods, 
headers, and exposed headers. 

The addMapping method is
used to register a mapping for all origins, methods, 
headers, and exposed headers. 

The allowedOrigins method
is used to specify the origins that are allowed to access
the resources.

The allowedMethods method is used to 
specify the HTTP methods that are allowed to access the
resources.

The allowedHeaders method is used to specify
the headers that are allowed to be sent with the request.

The exposedHeaders method is used to specify the headers that
are exposed to the client.

The allowCredentials method is
used to specify whether the client is allowed to send 
credentials with the request.

The maxAge method is used
to specify the maximum age (in seconds) of the preflight
*/



@Configuration
public class WebMvcConfiguration extends WebMvcConfigurationSupport {
	
	@Override
    protected void addCorsMappings(CorsRegistry registry) {
        // TODO Auto-generated method stub
        super.addCorsMappings(registry);
        registry.addMapping("/**") //used to register a mapping for all origins, methods, headers, and exposed headers 
                .allowedOrigins("*")
                .allowedMethods("*")
                .allowedHeaders("*")
                .exposedHeaders("*")
                .allowCredentials(false).maxAge(3600);
        }

}

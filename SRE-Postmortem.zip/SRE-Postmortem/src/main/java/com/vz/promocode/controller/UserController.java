package com.vz.promocode.controller;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vz.promocode.model.Role;
import com.vz.promocode.model.RoleName;
import com.vz.promocode.model.User;
import com.vz.promocode.repository.RoleRepository;
import com.vz.promocode.repository.UserRepository;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	UserRepository userRepository;

	@Autowired
	private PasswordEncoder encoder;

	@Autowired
	private RoleRepository roleRepository;

	@PostMapping("/addUser")
	public ResponseEntity<?> addUser(@RequestBody User user) {
		try {
			if (userRepository.existsByUsername(user.getUsername())) {
				return new ResponseEntity<>("Username is already existed", HttpStatus.FORBIDDEN);
			}
			if (userRepository.existsByMobile(user.getMobile())) {
				return new ResponseEntity<>("mobile is already existed", HttpStatus.FORBIDDEN);
			}
			if (userRepository.existsByEmail(user.getEmail())) {
				return new ResponseEntity<>("email is already existed", HttpStatus.FORBIDDEN);
			}

			Set<Role> set = new HashSet<>();

			if (user.getRole().equals("spadmin")) {
				Role adminRole = roleRepository.findByName(RoleName.ROLE_SPADMIN)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				set.add(adminRole);
			} else if (user.getRole().equals("admin")) {
				Role userRole = roleRepository.findByName(RoleName.ROLE_ADMIN)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				set.add(userRole);
			} else if (user.getRole().equals("user")) {
				Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				set.add(userRole);
			}

			User u = new User();
			u.setUsername(user.getUsername());
			u.setEmail(user.getEmail());
			u.setFname(user.getFname());
			u.setLname(user.getLname());
			u.setStatus("approved");
			u.setRoles(set);
			u.setRole(user.getRole());
			u.setCreatedDate(new Date());
			u.setMobile(user.getMobile());
			u.setPassword(encoder.encode("promocode"));
//			u.setBusinessPurpose(user.getBusinessPurpose());
			//u.setDepartmentId(user.getDepartmentId());

			userRepository.save(u);

			return new ResponseEntity<>("Success", HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>("Failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/updateUser")
	public ResponseEntity<?> createUser(@RequestBody User user) {
		try {
			Set<Role> set = new HashSet<>();

			if (user.getRole().equals("spadmin")) {
				Role adminRole = roleRepository.findByName(RoleName.ROLE_SPADMIN)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				set.add(adminRole);
			} else if (user.getRole().equals("admin")) {
				Role userRole = roleRepository.findByName(RoleName.ROLE_ADMIN)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				set.add(userRole);
			} else if (user.getRole().equals("user")) {
				Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				set.add(userRole);
			}

			User existed = userRepository.findById(user.getId()).get();

			if (existed != null) {
				existed.setFname(user.getFname());
				existed.setLname(user.getLname());
				existed.setUsername(user.getUsername());
				existed.setMobile(user.getMobile());
				existed.setEmail(user.getEmail());
				//existed.setDepartmentId(user.getDepartmentId());
				existed.setRole(user.getRole());
				existed.setRoles(set);

				userRepository.save(existed);
			} else {
				return new ResponseEntity<>("User id not recieved", HttpStatus.BAD_REQUEST);
			}

			return new ResponseEntity<>("Success", HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>("Failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/users")
	public ResponseEntity<List<User>> getAllUsers(@RequestParam(required = false) String title) {
		try {
			List<User> users = userRepository.findAllByOrderByIdDesc();

			return new ResponseEntity<>(users, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/users/{id}")
	public ResponseEntity<User> getUserById(@PathVariable("id") long id) {
		Optional<User> userData = userRepository.findById(id);

		if (userData.isPresent()) {
			return new ResponseEntity<>(userData.get(), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping("/users/{id}")
	public ResponseEntity<User> updateUser(@PathVariable("id") long id, @RequestBody User user) {
		Optional<User> userData = userRepository.findById(id);

		if (userData.isPresent()) {
			user.setId(userData.get().getId());
			return new ResponseEntity<>(userRepository.save(user), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/deleteUser/{id}")
	public ResponseEntity<HttpStatus> deleteUser(@PathVariable("id") long id) {
		try {
			userRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}

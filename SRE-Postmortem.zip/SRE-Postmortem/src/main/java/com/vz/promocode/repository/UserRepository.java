package com.vz.promocode.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.promocode.model.User;



@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	Optional<User> findByUsername(String userName);

	boolean existsByUsername(String username);

	boolean existsByMobile(String mobile);

	boolean existsByEmail(String email);

	@Transactional(readOnly=true)
	@Query("from User u where u.username=?1")
	User getUser(String username);

	@Transactional(readOnly=false)
	@Modifying
	void deleteByUsername(String username);

	@Modifying
	@Transactional(readOnly = false)
	@Query("update User u set u.fname=?1,u.lname=?2,u.email=?3,u.mobile=?4,u.businessPurpose=?5 where u.username=?6")
	int updateUserByUsername(String fname, String lname, String email, String mobile, String businessPurpose,String username);

	List<User> findAllByOrderByFname();

	List<User> findAllByUsernameOrderByFname(String username);

	@Transactional(readOnly=true)
	List<User> findAllByOrderByIdDesc();


}

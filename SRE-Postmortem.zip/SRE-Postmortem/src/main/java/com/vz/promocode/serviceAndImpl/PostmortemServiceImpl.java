package com.vz.promocode.serviceAndImpl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.poiji.bind.Poiji;
import com.vz.promocode.model.Incedents;
import com.vz.promocode.model.SearchHistory;
import com.vz.promocode.repository.IncedentRepository;
import com.vz.promocode.repository.SearchHistoryRepository;

@Service
public class PostmortemServiceImpl implements PostmortemService {

	@Autowired
	private IncedentRepository incedentRepo;

	@Autowired
	private SearchHistoryRepository historyRepo;

	@Override
	public ResponseEntity<?> readPostmortemExcelFile(List<MultipartFile> files) {
		try {
			List<Incedents> list = new ArrayList<>();
			ClassLoader cl = getClass().getClassLoader();
			File fileObj = new File(cl.getResource("temp.xlsx").getFile());
			File fileObj1 = new File(cl.getResource("temp.xls").getFile());

			for (MultipartFile file : files) {
				List<Incedents> incedents = new ArrayList<>();
				String extension = FilenameUtils.getExtension(file.getOriginalFilename());
				if (extension.equals("xlsx")) {
					try (OutputStream os = new FileOutputStream(fileObj)) {
						os.write(file.getBytes());
					}
					try {
						file.transferTo(fileObj1);
					} catch (Exception e) {
						e.printStackTrace();
					}
					incedents = Poiji.fromExcel(fileObj, Incedents.class);
				} else if (extension.equals("xls")) {
					try (OutputStream os = new FileOutputStream(fileObj1)) {
						os.write(file.getBytes());
					}
					try {
						file.transferTo(fileObj1);
					} catch (Exception e) {
						e.printStackTrace();
					}
					incedents = Poiji.fromExcel(fileObj1, Incedents.class);
				}
				System.out.println(incedents.size());
				list.addAll(incedents);
			}

			return new ResponseEntity<>(list, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>("Failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<?> savePostmortems(List<Incedents> ins) {
		try {
			incedentRepo.saveAll(ins);
			return new ResponseEntity<>("Incedents Saved Successfully", HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>("Failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<?> getPostmortems(String key) {
		try {
			List<Incedents> list = new ArrayList<>();
			ClassLoader cl = getClass().getClassLoader();
			File fileObj1 = new File(cl.getResource("temp.xls").getFile());
			list = Poiji.fromExcel(fileObj1, Incedents.class);

			list = list.stream().filter(li -> li.toString().toLowerCase().contains(key.toLowerCase()))
					.collect(Collectors.toList());
//			List<Incedents> list = incedentRepo.findAll();

			return new ResponseEntity<>(list, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>("Failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<?> saveSearchHistory(SearchHistory sh) {
		try {

			SearchHistory existed = historyRepo.findBySearchKey(sh.getSearchKey());

			if (existed != null) {
				existed.setCreatedOn(new Date());
				historyRepo.save(existed);
			} else {
				historyRepo.save(sh);
			}

			return new ResponseEntity<>("Search History Saved.", HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>("Failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<?> getSearchHistory(String username) {
		try {
			List<SearchHistory> list = historyRepo.findAllByCreatedBy(username);
			return new ResponseEntity<>(list, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>("Failed to get search history.", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
